#include "EntitySerializer.h" 
#include <iostream>

EntitySerializer::EntitySerializer()
{
    
}





int EntitySerializer::mempos ( char* haystack, int haylen, const char* needle, int needlelen )
{
   int currentPos=0;
    while (currentPos<haylen )
    {
       int ret=memcmp( (haystack+currentPos), needle,needlelen);
       if ( ret !=0 ) 
       { 
	//  std::cout<<"Not yet :"<<haystack+currentPos<<"\n";
	  currentPos+=sizeof(char);
       }
       else 
       {
	//  std::cout<<"Found it::"<<haystack+currentPos<<"\n";
	  return currentPos;
	  
       }
    }
}



Entity* EntitySerializer::deserialize(Buffer* entityBuffer)
{
  const char* startEntity ="<Entity>";
  const char* startField = "<field>";
  const char* endField = "</field>";
  const char* endEntity = "</Entity>";
 
   int startEntityPos=0;
   int startFieldPos=0;
   int endFieldPos=0;
   
   int currentPos=0;
   while (true)
   {
      std::cout<<"Start\n";
      char*  buffer = new char[1024];  
      
      int amountRead= entityBuffer->read(buffer,1024);
      if (startEntityPos==0)
      {
	startEntityPos=mempos(buffer, amountRead, startEntity,strlen(startEntity) +1);
	if (startEntityPos>= amountRead) 
	{
	  startEntityPos=-1; //No startEntity
	}
      }
       
       
      if (startEntityPos>0 && startFieldPos==0)
      {
	while (startFieldPos<amountRead)
	{
	     std::cout << "startFieldPos:"<<startFieldPos<<"\n";
	     std::cout << "endFieldPos:"<<endFieldPos<<"\n";
	      if (startFieldPos==0 && endFieldPos==0) 
	      {
		 startFieldPos =mempos((startEntityPos+buffer), amountRead, startField,strlen(startField) +1);
	      }
	      else if (endFieldPos>startFieldPos) 
	      { 
		startFieldPos =mempos( ((endFieldPos+strlen(endField) +1)+buffer), amountRead, startField,strlen(startField) +1);
		endFieldPos=0;
	      }
		  	      
	      if (startFieldPos>amountRead ) /*??fix*/
	      {
		startFieldPos=0;
		continue; /*??*/
	      }
	      
	      startFieldPos+=strlen(startField) +1;
	      
	      endFieldPos=mempos((startFieldPos+buffer), amountRead, endField,strlen(endField) +1);
	      
	      if (endFieldPos>amountRead )
	      {
		endFieldPos=0;
		continue; /*??*/
	      }
	      else
	      {
		
	        char* field = new char[1024];
	        memcpy(field,buffer+startFieldPos,endFieldPos-startFieldPos);
	        //fwrite(field, 8, 1, stdout); 
	      }
        }
      }
      std::cout<<"End\n";
   }
}


void EntitySerializer::serialize(Entity* entity,Buffer& output)
{
  const char* startEntity ="    <Entity>";
  const char* startField = "   <field>";
  const char* endField = "</field>";
  const char* endEntity = "</Entity>";
  
  char** names= entity->getFieldNames();
  int fieldAmount=entity->getFieldAmount();
  
  //int fieldSize=255+255+1;
  //int entitySize=sizeof(startEntity)+1+fieldSize*fieldAmount+sizeof(startEntity)+1;
 
  output.write(startEntity,strlen(startEntity)+1);
 
 for (int i=0; i<fieldAmount;i++)
  {
    output.write(startField,strlen(startField)+1);
   
    
    int len=strlen(names[i])+1;
    output.write(names[i],len);
    
     
    if (len<255)
    { 
      char tmpZero[255-len];
      memset(&tmpZero,0,255-len);
      output.write(tmpZero,255-len);
    }
    output.write(endField,strlen(endField)+1);
  }
  output.write(endEntity,strlen(endEntity)+1);
}

EntitySerializer::~EntitySerializer ( ) { }