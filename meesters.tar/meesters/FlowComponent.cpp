#include "FlowComponent.h"
//  
FlowComponent::FlowComponent ( ) { std::cout<< "PreProsessor::FlowComponent()" <<std::endl;}
FlowComponent::~FlowComponent ( ) { }

void FlowComponent::processData()
{
   // std::cout<< "FlowComponent::processData" <<std::endl;
    char* x=0;
  
    int amount=inputBuffer->read(&x,700);
     
    if (x)
    {
      std::cout<< "FlowComponent::processData() inputBuffer:"<<x <<std::endl;
      outputBuffer->write(x,amount);
      
      
    } 
   
}
  