#include "MaterlizationComponent.h"
//  
MaterlizationComponent::MaterlizationComponent ( ) { }
MaterlizationComponent::~MaterlizationComponent ( ) { }

void MaterlizationComponent::processData()
{
   
  while (1)
  {
    std::cout<< "MaterlizationComponent::processData()" <<std::endl;
  }
  
}
  