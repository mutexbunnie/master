#ifndef ENTITYSERIALIZER_H
#define ENTITYSERIALIZER_H
#include "Entity.h" 
#include "Buffer.h"
#include <string>


class EntitySerializer  
{
public:
  EntitySerializer ( );
  virtual ~EntitySerializer();
  void serialize(Entity* entity,Buffer& output);
  Entity* deserialize(Buffer* entity);
  int mempos ( char* haystack, int haylen, const char* needle, int needlelen );

};
#endif // ENTITYSERIALIZER_H

 