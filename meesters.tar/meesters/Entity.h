#ifndef ENTITY_H
#define ENTITY_H
#include "Field.h"
#include <vector>


class Entity
{
  
private:
  std::vector<Field*>* fields;

public:
Entity  (); 
~Entity ();  
char** getFieldNames();
void*   getFieldValue(char* fieldName);
void    removeField(char fieldName);
void    addField(char* fieldName,TYPE_ENUM type,void* fieldValue);
int    getFieldAmount() ;
char*  toString();

};



#endif // ENTITY_H*/

