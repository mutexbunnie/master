#ifndef PIPELINECOMPONENT_H
#define PIPELINECOMPONENT_H

#include <boost/bind.hpp>
#include <boost/shared_ptr.hpp>
#include "Buffer.h"


class PipelineComponent
{
public:
 
  PipelineComponent();
  virtual ~PipelineComponent();
   
  
  virtual void processData()=0;
  
  void process();
  
  void go();
  void stop();
  
    
  
  void setIn  (PipelineComponent* _in)  {in=_in;}
  void setOut (PipelineComponent* _out) {out=_out;}
  
 
  Buffer* inputBuffer;
  Buffer* outputBuffer;
  
 
protected:
 
 
  PipelineComponent* in;
  PipelineComponent* out; 

  
 
private:
    boost::shared_ptr<boost::thread> m_thread;
  

    
};
#endif // PIPELINECOMPONENT_H
