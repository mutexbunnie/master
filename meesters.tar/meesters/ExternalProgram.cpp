#include "ExternalProgram.h"
#include <iostream>
//  
ExternalProgram::ExternalProgram ( ) {}
ExternalProgram::~ExternalProgram ( ) { }

 
void ExternalProgram::processData()
{
   
  while (1)
  {
    std::cout<< "ExternalProgram::processData()" <<std::endl;
  }
  
}
  
 