#include "Buffer.h"

int Buffer::getBufferUsed()
{
   return buffPos;
}
 
int Buffer::getBufferLeft()
{
   return 65536-buffPos;
}

 
int Buffer::read(char* data,int bufSize)
{
      if (buffPos>0)
    {      
	  if (bufSize>buffPos) bufSize=buffPos;
	  
	  boost::lock_guard<boost::mutex> lock(mutex);
	  
	  
	
	//   std::cout<<"Reading from "<<(buffPos)-bufSize<<" to "<<(buffPos)<<std::endl;
	  
	  memcpy ((void*)data, buffer+(buffPos-bufSize) , bufSize );
	//  std::cout <<data <<std::endl;
	  buffPos-=bufSize;
	  return bufSize;
    }
    else return 0;
    
}

void Buffer::write(const char * data, int bufSize )
{
     boost::lock_guard<boost::mutex> lock(mutex);   
     if (buffPos<=65536-bufSize)
     {
       //  std::cout<<"Writing to "<<(buffPos)<<" to "<<(buffPos+bufSize)<<std::endl;
	memcpy (buffer+buffPos, data, bufSize );
	buffPos+=bufSize;
    } 
}

Buffer::Buffer()
{
  buffer=new char[65536];
  buffPos=0;
} 

Buffer::~Buffer ( ) 
{
             
}
 
 