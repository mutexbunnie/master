#include "TextMaterilzator.h"

TextMaterilzator::TextMaterilzator ( ) { }
TextMaterilzator::~TextMaterilzator ( ) { }

