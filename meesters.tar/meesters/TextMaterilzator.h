#ifndef TEXTMATERILZATOR_H
#define TEXTMATERILZATOR_H
#include "Materlizator.h"

class TextMaterilzator : public Materlizator
{
public:
 
  TextMaterilzator ( );
  virtual ~TextMaterilzator ( );

};
#endif // TEXTMATERILZATOR_H
