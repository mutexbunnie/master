#ifndef EXTERNALPROGRAM_H
#define EXTERNALPROGRAM_H
#include "PipelineComponent.h"

class ExternalProgram : public PipelineComponent
{
public:

  ExternalProgram ( );
  virtual ~ExternalProgram ( );
   void processData();


};
#endif // EXTERNALPROGRAM_H
