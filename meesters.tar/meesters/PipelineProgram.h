#ifndef PIPELINEPROGRAM_H
#define PIPELINEPROGRAM_H
#include "PipelineComponent.h"
 
class PipelineProgram : public PipelineComponent
{
public:
  PipelineProgram ( );
  virtual ~PipelineProgram ( );
  void processData();
 
};
#endif // PIPELINEPROGRAM_H
