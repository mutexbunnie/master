#ifndef MATERLIZATIONCOMPONENT_H
#define MATERLIZATIONCOMPONENT_H
#include "PipelineComponent.h"
class MaterlizationComponent : public PipelineComponent
{
public:
  
  MaterlizationComponent ( );
  virtual ~MaterlizationComponent ( );
  void processData();

};
#endif // MATERLIZATIONCOMPONENT_H
