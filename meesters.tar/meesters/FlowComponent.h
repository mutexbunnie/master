#ifndef FLOWCOMPONENT_H
#define FLOWCOMPONENT_H
#include "PipelineComponent.h"

class FlowComponent : public PipelineComponent
{
public:
  FlowComponent ( );
  virtual ~FlowComponent ( );
  void processData();

};
#endif // FLOWCOMPONENT_H
