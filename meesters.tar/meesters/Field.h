#include <string.h>  
// enum TYPE_ENUM {NO_WIND = 4, NORTH_WIND = 3, SOUTH_WIND = 2, EAST_WIND = 1, WEST_WIND = 0};

// 

enum TYPE_ENUM {str=0, integer=1};
class Field
{
    
  private:
  char* fieldName;
  TYPE_ENUM fieldType;
  void* fieldValue;
  
  
  public:
  Field (char* _fieldName,TYPE_ENUM _type,void* _fieldValue)
  {
     fieldName= new char[strlen(_fieldName)];
     memcpy(this->fieldName,_fieldName,strlen(_fieldName));
     fieldType=_type;
     fieldValue=_fieldValue; // prop copy with memcpy and sizeof (type)
  }
  
  char* getFieldName() {return  fieldName;}
  TYPE_ENUM getFieldType() {return  fieldType;}
  
  /*void* getFieldValue();*fix/add lasterz/*/

}; 
// 
// 
// 
