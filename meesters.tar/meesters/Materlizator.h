#ifndef MATERLIZATOR_H
#define MATERLIZATOR_H
 
class Materlizator
{
public:
 
  Materlizator ( );
  virtual ~Materlizator ( );
  
 
};
#endif // MATERLIZATOR_H
