#include "PipelineComponent.h"
#include <iostream>
#include <stdio.h>
#include <string.h>

PipelineComponent::PipelineComponent ( )
{
   in=0;
   out=0;
   std::cout<< "PipelineComponent::PipelineComponent ( )" <<std::endl;
   inputBuffer = new Buffer();
   outputBuffer = new Buffer();
}
   
void PipelineComponent::go() 
{
  assert(!m_thread);
  m_thread = boost::shared_ptr<boost::thread>(new boost::thread(boost::bind(&PipelineComponent::process, this)));
}
 
void PipelineComponent::process() 
{
  while (1)
  {
    if (in)
    {
          
	  
      char* tmpBuff=0;
        
      int bufferLeft= inputBuffer->getBufferLeft();
      
      int amount= in->outputBuffer->read(&tmpBuff, bufferLeft);
      
     // std::cout<<"Requesting "<< bufferLeft <<" from in "<<std::endl; 
      inputBuffer->write(tmpBuff,amount);
      //*fix get only as much as we can take
    }
      processData();
      
    if (out)
    {
      char* tmpBuff=0;
      int bufferLeft= out->inputBuffer->getBufferLeft();
     // std::cout<<"Requesting "<< bufferLeft <<" from out "<<std::endl;
      
      int amount=outputBuffer->read(&tmpBuff,bufferLeft);
      out->inputBuffer->write(tmpBuff,amount);
      //*fix send only as much as it can take
    }
  }
}
 

void PipelineComponent::stop()  
{
  assert(m_thread);
  m_thread->join();
}

PipelineComponent::~PipelineComponent ( ) 
{
             
}
 
 
