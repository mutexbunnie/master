#include "Entity.h"
#include <iostream>

Entity::Entity ( ) 
{
  fields = new  std::vector<Field*>();
}

Entity::~Entity ( ) { }

char**  Entity::getFieldNames()
{
  char** names = new char*[fields->size()];
  
  for (int i=0;  i< fields->size() ; i++)
  { 
    int nameSize=strlen(fields->at(i)->getFieldName());
    names[i] = new char[nameSize];
    memcpy(names[i],fields->at(i)->getFieldName(),nameSize);
  }

  return names;
}

void*  Entity::getFieldValue(char* fieldName) {}
void   Entity::removeField(char fieldName) {}

void   Entity::addField(char* fieldName,TYPE_ENUM type,void* fieldValue) 
{
   Field* tmpField = new Field(fieldName,type,fieldValue);
   fields->push_back(tmpField);
  
}


char*  Entity::toString() {}

int Entity::getFieldAmount() 
{
  return fields->size();
}