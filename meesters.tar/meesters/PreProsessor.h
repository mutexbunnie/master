#ifndef PREPROSESSOR_H
#define PREPROSESSOR_H
#include "PipelineComponent.h"
 
class PreProsessor : public PipelineComponent
{
public:
  
  PreProsessor ( );
  virtual ~PreProsessor ( );
   void processData();
   

};
#endif // PREPROSESSOR_H
