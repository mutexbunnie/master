#include "Materlizator.h"
//  
Materlizator::Materlizator ( ) {}
Materlizator::~Materlizator ( ) { }
