#ifndef BUFFER_H
#define BUFFER_H
#include <boost/thread.hpp>
#include <iostream>
#include <stdio.h>
#include <string.h>

class Buffer
{
public:
  Buffer ( );
  virtual ~Buffer ( );
  
  
 int read(char* data,int bufSize);
 void write (const char * data, int bufSize );
 int getBufferLeft();
 int getBufferUsed();
  
 
private:  
  int buffPos;
  char* buffer;
  boost::mutex mutex;
    

};
#endif // BUFFER_H
