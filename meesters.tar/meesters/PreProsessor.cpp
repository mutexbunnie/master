#include "PreProsessor.h"
#include <iostream>

PreProsessor::PreProsessor ( ) 
{ 
  
   std::cout<< "PreProsessor::PreProsessor()" <<std::endl;
  
}
PreProsessor::~PreProsessor ( ) 
{
 std::cout<< "PreProsessor::~PreProsessor ( ) " <<std::endl;  
}
 

void PreProsessor::processData()
{
  // std::cout<< " PreProsessor::processData" <<std::endl;
  
    char* x=0;
  
    int amount=inputBuffer->read(&x,700);
     
    if (x)
    {
      std::cout<< "PreProsessor::processData() inputBuffer:"<<x <<std::endl;
      outputBuffer->write(x,amount);
      
      
    } 
   
}