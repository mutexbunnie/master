#include "PipelineProgram.h"
   
PipelineProgram::PipelineProgram ( ) { }
PipelineProgram::~PipelineProgram ( ) { }
   
void PipelineProgram::processData()
{
   
  while (1)
  {
    std::cout<< "PipelineProgram::processData()" <<std::endl;
  }
  
}
  