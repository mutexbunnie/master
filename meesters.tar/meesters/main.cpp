//#include "PreProsessor.h"
//#include "FlowComponent.h"
//#include "MaterlizationComponent.h"
//#include "ExternalProgram.h"
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include  "Entity.h"
#include "EntitySerializer.h"
#include <stdio.h>
int main(int argc, char *argv[])
{
  
  /* PreProsessor* preProsessor = new PreProsessor();
   FlowComponent* flowComponent = new FlowComponent();
  //MaterlizationComponent* materlizationComponent = new MaterlizationComponent();
  //ExternalProgram* externalProgram = new ExternalProgram();
  
  preProsessor->go();
  flowComponent->go();
 // materlizationComponent->go();
//  externalProgram->go();
  
  
  
   preProsessor->setOut(flowComponent);
   flowComponent->setIn(preProsessor);
 
//   flowComponent->setOut(materlizationComponent);
//   materlizationComponent->setIn(materlizationComponent);
//   
//   materlizationComponent->setOut(externalProgram);
//   externalProgram->setIn(materlizationComponent);


    char* data="Bunnies";
      
    for (int i=0; i<100 ; i++)
    {
       preProsessor->inputBuffer->write(data,strlen(data));
    }
   
  preProsessor->stop(); 
  flowComponent->stop();
  

  
//   materlizationComponent->stop();
//   externalProgram->stop();*/
 
  Entity* tmpEntity = new Entity();
  tmpEntity->addField("Mangoo1",str,0) ;
  tmpEntity->addField("Mangoo2",str,0) ;
  tmpEntity->addField("Mangoo3",str,0) ;
  
  Buffer output;
  
  EntitySerializer* tmpEntitySerializer =new EntitySerializer();
  tmpEntitySerializer->serialize(tmpEntity,output);
  
  //char* res = new char[1024];
  //output.read(res,1024);
  //fwrite(res, 1024, 1, stdout); 
  
  tmpEntitySerializer->deserialize(&output);


}